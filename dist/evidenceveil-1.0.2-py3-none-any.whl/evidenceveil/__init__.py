"""EvidenceVeil public package."""

from .version import __version__

__all__ = ["__version__"]
